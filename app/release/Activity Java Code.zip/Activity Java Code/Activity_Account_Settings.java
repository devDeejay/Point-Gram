package com.devdelhi.pointgram.pointgram;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import de.hdodenhof.circleimageview.CircleImageView;

public class Activity_Account_Settings extends AppCompatActivity {

    private DatabaseReference mDatabaseReference;
    private FirebaseUser mCurrentUser;
    private FirebaseAuth mAuth;

    private ProgressDialog mProgressDialog;

    private CircleImageView display_pic_IV;
    private TextView displayNameTV, statusTV;
    private String TAG = "DEEJAY";
    private String current_uid;
    private static final int GALLERY_PICK = 1;
    private String statusString;
    private Button changeStatusButton, changePictureButton;
    private StorageReference mImageStorage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__account__settings);

        changeStatusButton = findViewById(R.id.changeStatusButton);
        changePictureButton = findViewById(R.id.changeImageButton);

        mAuth = FirebaseAuth.getInstance();
        mCurrentUser = mAuth.getCurrentUser();
        current_uid = mCurrentUser.getUid();
        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Users").child(current_uid);
        mImageStorage = FirebaseStorage.getInstance().getReference();

        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setTitle("Please Wait");
        mProgressDialog.setMessage("We are getting your Name, Image And Status.");
        mProgressDialog.setCanceledOnTouchOutside(false);

        display_pic_IV = findViewById(R.id.user_display_image);
        displayNameTV = findViewById(R.id.user_display_name);
        statusTV = findViewById(R.id.user_display_status);

        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String name = dataSnapshot.child("Name").getValue().toString();
                String status = dataSnapshot.child("Status").getValue().toString();
                String image = dataSnapshot.child("Image").getValue().toString();
                String thumbnail = dataSnapshot.child("Thumbnail").getValue().toString();

                Log.d(TAG, "Retrived Name is " + name);
                Log.d(TAG, "Retrived status is " + status);

                statusString = status;
                displayNameTV.setText(name);
                statusTV.setText(status);
                Picasso.with(Activity_Account_Settings.this).load(image).into(display_pic_IV);

                mProgressDialog.hide();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                mProgressDialog.hide();
            }
        });

        changeStatusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Activity_Account_Settings.this, Activity_Status.class);
                intent.putExtra("Status", statusString);
                startActivity(intent);
            }
        });

        changePictureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent galleryIntent = new Intent();
                galleryIntent.setType("image/*");
                galleryIntent.setAction(galleryIntent.ACTION_GET_CONTENT);

                startActivityForResult(Intent.createChooser(galleryIntent, "SELECT IMAGE"), GALLERY_PICK);
            }
        });
    }

    private boolean isUserSignedIn() {
        boolean isSignedin = false;

        FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() != null) {
            isSignedin = true;
        }
        return isSignedin;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == GALLERY_PICK && resultCode == RESULT_OK) {
            Uri imageURI = data.getData();
            CropImage.activity()
                    .setAspectRatio(1,1)
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .start(Activity_Account_Settings.this);

        }

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                mProgressDialog.setTitle("Please Wait");
                mProgressDialog.setMessage("We are Changing Your Picture.");
                mProgressDialog.setCanceledOnTouchOutside(false);
                mProgressDialog.show();

                Uri resultUri = result.getUri();
                StorageReference filepath = mImageStorage.child("Profile_Images").child(current_uid+".jpg");
                filepath.putFile(resultUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if (task.isSuccessful()) {
                            String downloadURL = task.getResult().getDownloadUrl().toString();
                            mDatabaseReference.child("Image").setValue(downloadURL).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()){
                                        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "Picture Saved.", Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                    }
                                    else {
                                        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "Failed To Save Picture.", Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                    }
                                }
                            });
                        }
                        else {
                            Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "Failed To Save Picture.", Snackbar.LENGTH_LONG);
                            snackbar.show();
                        }
                        mProgressDialog.dismiss();
                    }
                });

            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
            }
        }
    }
}
