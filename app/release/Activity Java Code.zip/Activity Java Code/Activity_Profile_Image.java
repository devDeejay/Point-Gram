package com.devdelhi.pointgram.pointgram;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

public class Activity_Profile_Image extends AppCompatActivity {

    private Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__profile__image);

        mToolbar = findViewById(R.id.profile_image_toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Change Your Picture");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
}
