package com.devdelhi.pointgram.pointgram;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class Fragment_MyActivity extends Fragment {

    private int MY_PERMISSION_REQUEST_FINE_LOCATION = 1;
    private BroadcastReceiver broadcastReceiver;
    private TextView coordinatesTextView;

    public Fragment_MyActivity() {
        // Required empty public constructor
    }

    @Override
    public void onResume() {
        super.onResume();

        if (broadcastReceiver == null) {
            broadcastReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {

                    Bundle bundle = intent.getExtras();

                    String lat,lng;
                    lat = intent.getStringExtra("lat");
                    lng = intent.getStringExtra("lng");

                    Log.d("DEEJAY", "Got Data" + lat + " " + lng);
                    coordinatesTextView.append("\n" + lat + " , " + lng);
                }
            };
        }

        getActivity().registerReceiver(broadcastReceiver, new IntentFilter("User_Update")); // Calls onReceive Method

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_my_activity, container, false);
        coordinatesTextView = view.findViewById(R.id.coordinatesTextView);
        Button myCustomButton = view.findViewById(R.id.startMapForUser);

        myCustomButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (checkRunTimePermissions()) {
                    startLocationService();
                    Intent firstpage = new Intent(getActivity(),Activity_Maps.class);
                    getActivity().startActivity(firstpage);
                }
                else {
                    checkRunTimePermissions();
                    Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), "Please Grant The Permissions.", Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        });

        return view;
    }


    private boolean checkRunTimePermissions() {
        boolean permissionIsGranted = false;
        if (ContextCompat.checkSelfPermission(getActivity(),
                android.Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(getActivity(),
                        android.Manifest.permission.ACCESS_COARSE_LOCATION) !=
                        PackageManager.PERMISSION_GRANTED) {

                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                // int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new
                                String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSION_REQUEST_FINE_LOCATION);
            } else {
                permissionIsGranted = true;
            }
        }
        else {
            permissionIsGranted = true;
        }
        return  permissionIsGranted;/*
        if (Build.VERSION.SDK_INT >= 23 && ContextCompat.checkSelfPermission(getActivity(),
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(getActivity(),
                android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION},
                    100);
            return  true;
        }
        return false; // We don't need to ask for Permissions*/
    }

    public void startLocationService() {
        Intent intent = new Intent(getActivity(), Service_GPS.class);
        getActivity().startService(intent);
    }
}
