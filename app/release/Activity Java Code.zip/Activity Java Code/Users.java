package com.devdelhi.pointgram.pointgram;

public class Users {
    public String Name;
    public String Email;
    public String Thumbnail;
    public String Image;
    public String Status;

    public Users() {}

    public Users(String name, String email, String thumbnail, String image, String status) {
        Name = name;
        Email = email;
        Thumbnail = thumbnail;
        Image = image;
        Status = status;
    }


    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        this.Image = image;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        this.Status = status;
    }

}
